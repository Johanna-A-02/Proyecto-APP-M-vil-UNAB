package com.example.appmovilunab;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class Listado_estudiantes extends AppCompatActivity {

    private View button;
    private TextView textView1;
    private TextView limpiar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado_estudiantes);
    }
    public void viewHistorial(View view) {
        //textView1.setText("FUNCIONA");
        switch (view.getId()){
//
//            case R.id.btnHistBackProf:
//                Intent intentHist=new Intent(Listado_estudiantes.this, homeAdmin.class);
//                startActivity(intentHist);
//                break;
//            case R.id.btnHistLogProf:
//                Intent intentLogout=new Intent(ListadoEstudiantes.this, LoginActivity.class);
//                startActivity(intentLogout);
//                break;
            case R.id.ProfDetails:
                Intent intentDetails=new Intent(Listado_estudiantes.this, MainActivity.class);
                startActivity(intentDetails);
                break;
//            case R.id.btnNext:
//                Intent intentListView=new Intent(Listado_estudiantes.this, ListViewEstudiantes.class);
//                startActivity(intentListView);
//                break;





        }



        // Do something in response to button click
    }
}